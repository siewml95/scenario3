package javafxapplication;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;
/**
 *
 * @author User
 */
public class JavaFXApplication extends Application {
    
    private int batteryVal;
    
    @Override
    public void start(Stage primaryStage) {
        
        Image batteryImg = new Image(getClass().getResourceAsStream("battery.png"));
        
        ImageView batteryView = new ImageView(batteryImg);
        batteryView.setFitWidth(50);
        batteryView.setPreserveRatio(true);
        
        Button batteryBtn = new Button("Battery", batteryView);
        batteryBtn.setStyle("-fx-font: 16 'Times New Roman';");
        batteryBtn.setContentDisplay(ContentDisplay.TOP);
        
        Button batterySbmt = new Button("Submit");
        batterySbmt.setStyle("-fx-font: 15 'Times New Roman';");
        batterySbmt.setMaxWidth(80);
        batterySbmt.setMaxHeight(12);
        
        final Label label1 = new Label("  Voltage");
        label1.setStyle("-fx-font: 15 'Times New Roman'; -fx-font-weight: bold;");
        final Label label2 = new Label("V");
        label2.setStyle("-fx-font: 15 'Times New Roman';");
        TextField textField = new TextField ("9");
        textField.setMaxWidth(80);
        
        HBox hBox = new HBox();
        hBox.setSpacing(10); 
        hBox.setAlignment(Pos.CENTER_LEFT);
        hBox.getChildren().addAll(label1, textField, label2, batterySbmt);
        
        StackPane root = new StackPane();
        root.getChildren().add(batteryBtn);
        
        batteryBtn.setOnAction(new EventHandler<ActionEvent>() {

        @Override
        public void handle(ActionEvent e) {
           
            root.getChildren().add(hBox);            
        }
 });      
        
        batterySbmt.setOnAction(new EventHandler<ActionEvent>() {

        @Override
        public void handle(ActionEvent e) {
            if ((textField.getText() != null && !textField.getText().isEmpty())) {
                try{
                batteryVal = Integer.parseInt(textField.getText());
                }
                catch (NumberFormatException nfe){
                textField.setText("Invalid input!");
                batteryVal = 9;
                }    
                System.out.println(batteryVal);
            } else {
                textField.setText("Invalid input!");
            }
     }
 });
              
        Scene scene = new Scene(root, 800, 500);
        
        primaryStage.setTitle("Circuit Diagram");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
